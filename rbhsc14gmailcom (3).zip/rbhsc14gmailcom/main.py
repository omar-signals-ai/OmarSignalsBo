import requests
import time
import telegram

# إعدادات البوت
TOKEN = "7417533427:AAFiHzYJRluoH7q1jkzoR9SqKZeovUzBrME"
CHAT_ID = 7420171743
bot = telegram.Bot(token=TOKEN)

# دالة لجلب الأسعار من الإنترنت
def get_prices():
    try:
        gold = requests.get("https://api.metals.live/v1/spot/gold").json()[0]["gold"]
    except:
        gold = None
    try:
        bitcoin = requests.get("https://api.coindesk.com/v1/bpi/currentprice/USD.json").json()["bpi"]["USD"]["rate_float"]
    except:
        bitcoin = None
    try:
        silver = requests.get("https://api.metals.live/v1/spot/silver").json()[0]["silver"]
    except:
        silver = None
    try:
        gas = requests.get("https://api.api-ninjas.com/v1/commodities?name=natural_gas",
                           headers={"X-Api-Key": "demo"}).json()[0]["price"]
    except:
        gas = None
    return gold, bitcoin, silver, gas

# دالة إرسال التوصيات عند تحقق الشروط
def send_signal():
    gold, bitcoin, silver, gas = get_prices()
    msg = "توصيات عمر - فرص حقيقية مباشرة:\n"
    found = False

    if gold and gold < 2300:
        msg += f"\nشراء الذهب 🟡 - السعر: {gold:.2f} - الهدف: {gold+20:.2f} - الوقف: {gold-15:.2f}"
        found = True

    if bitcoin and bitcoin < 61000:
        msg += f"\n\nشراء بيتكوين 🟠 - السعر: {bitcoin:.2f} - الهدف: {bitcoin+3000:.2f} - الوقف: {bitcoin-2000:.2f}"
        found = True

    if silver and silver > 28:
        msg += f"\n\nبيع الفضة ⚪ - السعر: {silver:.2f} - الهدف: {silver-1.5:.2f} - الوقف: {silver+0.7:.2f}"
        found = True

    if gas and gas < 2.2:
        msg += f"\n\nشراء الغاز 🔵 - السعر: {gas:.2f} - الهدف: {gas+0.25:.2f} - الوقف: {gas-0.1:.2f}"
        found = True

    if found:
        bot.send_message(chat_id=CHAT_ID, text=msg)
    else:
        print("لا توجد فرص حالياً")

# حلقة تشغيل مستمرة كل 60 ثانية
while True:
    send_signal()
    time.sleep(60)